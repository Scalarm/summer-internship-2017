#!/usr/bin/env python2.6
print "Hello World"