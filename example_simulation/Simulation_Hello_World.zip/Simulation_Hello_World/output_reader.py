#!/usr/bin/env python2.6
import json
results = { "status": "ok", "results": { "hello world": "hello world" } }
with open('output.json', 'wb+') as f:
    f.write(json.dumps(results))